// Отчет: https://contest.yandex.ru/contest/22781/run-report/70832502/

#include <cassert>
#include <string>
#include <stack>
#include <iostream>

class MyCircularDequeue
{

public:
    MyCircularDequeue(int max_size) : max_size_(max_size) {}

    void push_front(int x)
    {
        if (size_ == max_size_)
        {
            std::cout << "error\n";
            return;
        }
        head = (head == 0 ? max_size_ : head) - 1;
        buf[head] = x;
        size_++;
        return;
    }
    
    void pop_front()
    {
        if (size_ == 0)
        {
            std::cout << "error\n";
            return;
        }
        std::cout << buf[head] << '\n';
        head = (head + 1) % max_size_;
        size_--;
    }

    void push_back(int x)
    {
        if (size_ == max_size_)
        {
            std::cout << "error\n";
            return;
        }
        buf[tail] = x;
        tail = (tail + 1) % max_size_;
        size_++;
        return;
    }
        
    void pop_back()
    {
        if (size_ == 0)
        {
            std::cout << "error\n";
            return;
        }
        tail = (tail == 0 ? max_size_ : tail) - 1;
        size_--;
        std::cout << buf[tail] << '\n';
    }

private:
    int size_ = 0;
    int max_size_;
    int buf[50000];
    int head = 0;
    int tail = 0;
};

int main()
{
    int n;
    std::cin >> n;
    int max_size;
    std::cin >> max_size;
    MyCircularDequeue *myqueue = new MyCircularDequeue(max_size);

    std::string cmd;
    std::string arg;
    int val;
    for (int i = 0; i < n; i++)
    {
        std::cin >> cmd;
        if (cmd == "push_back")
        {
            std::cin >> arg;
            val = std::stoi(arg);
            myqueue->push_back(val);
        }
        else if (cmd == "push_front")
        {
            std::cin >> arg;
            val = std::stoi(arg);
            myqueue->push_front(val);
        }
        else if (cmd == "pop_front")
        {
            myqueue->pop_front();
        }
        else if (cmd == "pop_back")
        {
            myqueue->pop_back();
        }        
    }

    return 0;
}
